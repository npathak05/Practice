package com.myservice.auth.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class MyAuthServiceImpl implements MyAuthService{

	@Override
	public String authenticateService(String name, String password) {
		String result = "{'authResult': 'success', 'applicationConfigurationURLs': {'accSummaryUrl': '/accservices/556677/accounts', 'loanSummaryUrl': '/loanservices/556677/loans', 'transactionDetailsUrl': '/txnservices/1000/accounts', 'payeeListUrl': '/accservices/556677/payeeList', 'cardSummaryUrl': '/accservices/556677/cards', 'investmentSummaryUrl': '/accservices/556677/investments'}}";
		return result;
	}

 

}

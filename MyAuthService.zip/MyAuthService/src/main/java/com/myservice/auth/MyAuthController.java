package com.myservice.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.myservice.auth.service.MyAuthService;

@RestController
@RequestMapping("/authservice")
@CrossOrigin
@EnableAutoConfiguration
public class MyAuthController {

	@Autowired
	private MyAuthService service;

	@RequestMapping("/")
	public String testService() {
		return "Auth WS service ";
	}

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST,headers="Accept=application/json")
	@ResponseBody
	public ResponseEntity<String> authenticate(@RequestBody MyUser user) {
		System.out.println("in Auth server#############:name: "+user.getUserName()+"  pwd:"+user.getPassword());
		String s = service.authenticateService(user.getUserName(),user.getPassword());
		return new ResponseEntity<String>(s,HttpStatus.OK);
	}

}

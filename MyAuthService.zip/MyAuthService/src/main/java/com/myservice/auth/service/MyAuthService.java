package com.myservice.auth.service;

import java.util.List;

public interface MyAuthService {

	String authenticateService(String name, String password);


}
